BladeTurkey Dark UI v0.6
Minecraft Java Edition 1.21.11

Icerik:
- Susluu mor buton spritelari (normal / hover / disabled), 9-slice ayarli
- Duraklatma (ESC) menusu: BT logosu (font glyph ile)
- Envanter GUI: sarmasikli/cicekli mor tema, ozel cizim (inventory.png) + slot spritelari
- Envanter HUD: yaprakli mor hotbar, parlayan secili slot cercevesi, offhand
- Metinler:
  Back to Game -> BladeTurkey'e don
  Disconnect   -> Yine Bekleriz

Kurulum:
1. ZIP'i .minecraft/resourcepacks klasorune at
2. Options > Resource Packs'ten etkinlestir

Logo boyutu: assets/minecraft/font/default.json icindeki "height" ve "ascent"
(ikisi esit kalsin). Buyutmek icin artir, kucultmek icin azalt.

Not: Envanterdeki "Crafting"/"Envanter" yazilari oyunda sabit koyu gri renkte,
bu yuzden panel acik lavanta tutuldu; koyu panelde yazilar okunmazdi.
